<?php

namespace App\Actions\Fire;

class ImageAction
{
    //
}
