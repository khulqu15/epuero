<template>

</template>

<script>
export default {
    name: "Index.vue"
}
</script>

<style scoped>

</style>
