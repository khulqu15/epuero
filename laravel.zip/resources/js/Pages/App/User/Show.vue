<template>

</template>

<script>
export default {
    name: "Show.vue"
}
</script>

<style scoped>

</style>
