<template>

</template>

<script>
export default {
    name: "Create"
}
</script>

<style scoped>

</style>
