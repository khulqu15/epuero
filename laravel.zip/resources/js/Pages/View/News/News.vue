<template>
    <Head>
        <title>News - Epuero</title>
        <meta name="description" content="News - Eepis Plane Unit Operational Rescue Forest">
    </Head>
    <view-layout active="news">
        <template v-slot:content>
            <div class="relative" id="news">
                <div class="grid grid-cols-3 gap-3">
                    <div class="col-span-3 md:col-span-2 pt-36 pb-12 px-8 space-y-6 md:px-12">
                        <a href="/" class="text-gray-900 relative -top-3 bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-200 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700">
                            <Icon icon="akar-icons:arrow-left" class="text-xl inline-block"/>
                            <span>Back</span>
                        </a>
                        <img src="/images/news/news1.jpg" class="w-full rounded-lg" alt="News 1">
                        <div class="space-y-3">
                            <h1 class="text-3xl font-bold mb-3">Lorem ipsum dolor sit amet consectetur adipisicing elit. Eius, nulla!</h1>
                            <span class="text-gray-600">Monday, 20 April 2022</span>
                        </div>
                        <p>
                            Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quos, nesciunt ea. Temporibus aperiam, ipsa neque incidunt aliquam nisi ex ullam distinctio! Quam aspernatur perspiciatis exercitationem odio odit ex alias aperiam cupiditate animi est sapiente, perferendis rerum in ipsam amet sint magnam dolorem accusantium? Vero vitae eveniet obcaecati odio cumque nulla excepturi alias voluptatibus voluptatum ipsa pariatur nobis labore, porro ullam vel rem id debitis quibusdam similique exercitationem, est temporibus nisi molestias accusamus. Vero alias, dignissimos possimus inventore dolorum aspernatur voluptas suscipit impedit et facilis assumenda incidunt, eos saepe! Laborum, minus voluptatibus debitis incidunt a ut nobis expedita labore autem ullam quo neque harum ea, aliquam rem. Magni deserunt odit assumenda repellendus aperiam facere earum alias vitae impedit necessitatibus maxime illum vel aliquid suscipit officiis voluptas itaque perspiciatis quam, et soluta qui! Maiores libero deleniti sunt. Quidem maiores est et fugiat atque vitae exercitationem deleniti quis. Iusto odit impedit consequatur officiis consequuntur doloremque quas dolor non nulla, ipsa commodi, dolorum perspiciatis, magni voluptates nesciunt? Minima vel quibusdam sapiente fugit quas nesciunt, quo saepe aspernatur expedita sequi eum. Earum eos ab possimus eveniet, itaque officiis dignissimos deserunt vel! Doloremque porro quidem inventore error qui non maxime nemo consectetur dolorum. Et natus minus eaque fugiat dignissimos, odio itaque laborum modi, adipisci id ullam excepturi! Cupiditate repellendus molestias cumque laborum accusantium fugit, optio quisquam facilis consequatur quia, porro vero libero quas quis eius reprehenderit, unde omnis maxime. Qui cum molestiae voluptatem saepe ducimus modi illo vel non, esse porro, dolore sed? Veritatis eum aliquid omnis maiores soluta dicta iste ut mollitia impedit corrupti repellendus temporibus consectetur esse, sapiente quas voluptates nobis libero accusantium asperiores deleniti aperiam sit excepturi. Nostrum explicabo est sapiente a velit, illum placeat rem ipsam excepturi nesciunt ducimus tenetur blanditiis expedita vel cupiditate aspernatur consequatur repellendus repellat laudantium. Debitis labore corrupti explicabo unde atque, magni quasi sint a dolorem porro maxime pariatur, voluptas rem omnis libero perferendis ipsum beatae? Rerum odio error, deleniti placeat cum laudantium in eos quia a accusantium dolore adipisci assumenda suscipit? Officiis velit voluptatum rerum repudiandae aspernatur necessitatibus id ratione, tempore laborum sunt? Adipisci repellendus nesciunt numquam eaque ex maxime officiis quam consectetur. Vel non asperiores illum harum temporibus aliquam laborum ducimus, esse nemo hic distinctio provident assumenda natus cum numquam impedit ex quam, unde mollitia doloribus. Vel eveniet dignissimos atque rem aspernatur culpa amet, optio dicta illo libero a porro sequi minus architecto dolorum facere ad placeat debitis maiores blanditiis cumque, qui exercitationem omnis! Culpa necessitatibus eum voluptatibus? Repellat magnam consequatur perspiciatis ea molestias laudantium, itaque nesciunt sequi quam recusandae beatae dignissimos non similique delectus laborum inventore dolore harum? Incidunt totam ipsum placeat molestiae cumque asperiores hic, excepturi harum corrupti. Similique corporis est minus. Rem sapiente maiores officia totam, laborum qui quis nostrum molestiae. Vel optio laudantium laborum numquam delectus quasi, nostrum excepturi nobis architecto esse expedita, provident eum tempore neque alias! Magni hic a ad expedita eligendi odit. Totam obcaecati esse consectetur incidunt! Excepturi repellat aperiam cumque iusto consequatur sunt, atque aliquid pariatur earum perferendis quibusdam itaque voluptatem temporibus quod ipsam delectus dolores quae necessitatibus. Sapiente libero ullam maiores sunt architecto eius similique doloribus neque ad rerum dolores aperiam incidunt delectus error nam qui expedita pariatur atque labore reiciendis, officia sint assumenda! Exercitationem sapiente est odit dolorum repellendus tempore voluptatum similique ea illum quasi ipsum harum culpa amet maxime doloribus corrupti ipsa optio quaerat earum, fugit quisquam! In expedita nam, neque voluptates quisquam facere possimus voluptate molestiae minima deserunt reiciendis eligendi vitae quos ex veniam nisi ad pariatur dolorum velit repudiandae deleniti autem ipsum odit. Exercitationem nisi, temporibus neque animi accusantium, ab porro facere assumenda voluptatibus dolores tenetur fugit, omnis quidem. Voluptas explicabo, commodi quibusdam officiis illo suscipit voluptatem quisquam, totam nemo aliquid nisi quod facilis? Quibusdam at expedita molestias suscipit magnam quasi voluptas consequuntur neque odio recusandae saepe sint placeat facilis, dolore atque voluptatibus et porro distinctio. Rerum, a maiores assumenda ad cupiditate odio voluptatem animi, architecto doloremque consequuntur ullam quisquam dignissimos nisi? Aspernatur explicabo, dolore dignissimos temporibus aut consequuntur id sunt ipsum consequatur neque voluptatibus, perferendis dolores necessitatibus ut voluptatem nemo obcaecati ea saepe eius. Laborum blanditiis quisquam inventore nihil laboriosam incidunt rem, itaque vero! Ullam illo obcaecati pariatur sapiente ipsam, alias fugit debitis, et corrupti, quibusdam iusto officia unde maxime totam. Unde laudantium quam repellat sint. A reprehenderit esse non, officia porro atque accusamus dolorem voluptatum harum vel ducimus, eveniet eius, cum explicabo qui optio tempore quia consectetur impedit veritatis dicta est aspernatur quidem? Rem exercitationem aut temporibus, voluptate molestiae voluptates eos? Illo sit reprehenderit consequatur dolorem praesentium qui voluptatem quis sunt, rem quo ut asperiores animi nam. Aperiam aliquam soluta alias, unde a voluptatem dolorem id excepturi debitis eligendi facere, provident veritatis cupiditate culpa dicta sunt quaerat deleniti minus inventore dolorum illum corporis dignissimos ipsa! Cupiditate reprehenderit temporibus maiores dolore architecto ab exercitationem, qui expedita at velit enim dolorem id ut beatae ex ipsam animi iure incidunt numquam rerum asperiores cum. Dolorem pariatur quaerat doloremque itaque dolorum illum mollitia voluptatibus earum ipsa fuga cum omnis cupiditate tempora rem assumenda deleniti est ullam enim voluptatem error aut, ducimus nemo exercitationem neque. Accusantium eos ullam, accusamus perspiciatis quas eum enim similique harum? Amet ipsam nobis aliquam commodi quo, sunt atque sint doloribus, optio porro, maiores quae quod temporibus accusantium consectetur itaque a. Culpa ducimus omnis a! Dolor est mollitia fuga veniam eaque eius itaque, consequatur laboriosam quis illum dicta accusamus voluptates corrupti dolores temporibus possimus alias sunt optio esse consectetur impedit non odio? Expedita labore aliquam inventore. Aspernatur, sed ut. Voluptas optio maiores adipisci necessitatibus vitae voluptatem laudantium aperiam accusamus veniam, officia animi nesciunt dolore, possimus sint cum molestiae quia qui amet at ullam numquam nobis? Animi doloribus non tenetur culpa minima ad, exercitationem numquam. Natus, laboriosam? Modi sapiente perferendis minima dolor dolorum ut quam repellat expedita, aspernatur corrupti eum in consequuntur accusantium culpa, iste exercitationem, accusamus ex ipsa quia inventore porro! Sunt at tenetur est animi quod nobis impedit, consequuntur vitae magnam fuga repellendus ducimus esse quibusdam atque veritatis. Veniam, tempore expedita.
                        </p>
                    </div>
                    <div class="col-span-3 md:col-span-1 min-h-screen relative px-8 w-full border-l border-gray-200 pt-36 pb-12 overflow-visible">
                        <div class="sticky top-36">
                            <button data-modal-toggle="shareModal" class="relative inline-flex items-center justify-center w-full p-0.5 mb-6 mr-2 overflow-hidden text-sm font-medium text-gray-900 rounded-lg group bg-gradient-to-br from-cyan-500 to-blue-500 group-hover:from-cyan-500 group-hover:to-blue-500 hover:text-white dark:text-white focus:ring-4 focus:outline-none focus:ring-cyan-200 dark:focus:ring-cyan-800">
                                <span class="relative w-full px-5 py-2.5 transition-all ease-in duration-75 bg-white dark:bg-gray-900 rounded-md group-hover:bg-opacity-0">
                                    Share news
                                </span>
                            </button>
                            <h3 class="font-semibold text-xl mb-4">More awesome news</h3>
                            <a href="/news" v-for="(item, index) in 3" class="flex flex-col mb-3 items-center bg-white rounded-lg border shadow-md md:flex-row md:max-w-xl hover:bg-gray-100 dark:border-gray-700 dark:bg-gray-800 dark:hover:bg-gray-700">
                                <div class="relative w-48">
                                    <img class="object-cover self-stretch w-full h-36 rounded-none rounded-l-lg" :src="`/images/news/news${item}.jpg`" alt="">
                                </div>
                                <div class="flex flex-col justify-between p-4 leading-normal">
                                    <h5 class="mb-2 text-lg font-bold tracking-tight text-gray-900 dark:text-white">Noteworthy technology acquisitions 2021</h5>
                                    <p class="mb-3 text-sm text-gray-700 dark:text-gray-400">Here are the biggest enterprise technology acquisitions of 2021</p>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div id="shareModal" tabindex="-1" aria-hidden="true" class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 w-full md:inset-0 h-modal md:h-full">
                <div class="relative p-4 w-full max-w-2xl h-full md:h-auto">
                    <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">
                        <div class="flex justify-between items-start p-4 rounded-t">
                            <h3 class="text-xl font-semibold text-gray-900 dark:text-white">
                                Share news
                            </h3>
                            <button type="button" class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center dark:hover:bg-gray-600 dark:hover:text-white" data-modal-toggle="shareModal">
                                <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"></path></svg>
                            </button>
                        </div>
                        <div class="p-6 space-y-6">
                            <div class="my-4">
                                <p class="text-sm">Share this link via</p>

                                <div class="flex justify-around my-4">
                                    <!--FACEBOOK ICON-->
                                    <div
                                    class="border hover:bg-[#1877f2] w-12 h-12 fill-[#1877f2] hover:fill-white border-blue-200 rounded-full flex items-center justify-center shadow-xl hover:shadow-blue-500/50 cursor-pointer"
                                    >
                                    <svg
                                        xmlns="http://www.w3.org/2000/svg"
                                        width="24"
                                        height="24"
                                        viewBox="0 0 24 24"
                                    >
                                        <path
                                        d="M13.397 20.997v-8.196h2.765l.411-3.209h-3.176V7.548c0-.926.258-1.56 1.587-1.56h1.684V3.127A22.336 22.336 0 0 0 14.201 3c-2.444 0-4.122 1.492-4.122 4.231v2.355H7.332v3.209h2.753v8.202h3.312z"
                                        ></path>
                                    </svg>
                                    </div>
                                    <!--TWITTER ICON-->
                                    <div
                                    class="border hover:bg-[#1d9bf0] w-12 h-12 fill-[#1d9bf0] hover:fill-white border-blue-200 rounded-full flex items-center justify-center shadow-xl hover:shadow-sky-500/50 cursor-pointer"
                                    >
                                    <svg
                                        xmlns="http://www.w3.org/2000/svg"
                                        width="24"
                                        height="24"
                                        viewBox="0 0 24 24"
                                    >
                                        <path
                                        d="M19.633 7.997c.013.175.013.349.013.523 0 5.325-4.053 11.461-11.46 11.461-2.282 0-4.402-.661-6.186-1.809.324.037.636.05.973.05a8.07 8.07 0 0 0 5.001-1.721 4.036 4.036 0 0 1-3.767-2.793c.249.037.499.062.761.062.361 0 .724-.05 1.061-.137a4.027 4.027 0 0 1-3.23-3.953v-.05c.537.299 1.16.486 1.82.511a4.022 4.022 0 0 1-1.796-3.354c0-.748.199-1.434.548-2.032a11.457 11.457 0 0 0 8.306 4.215c-.062-.3-.1-.611-.1-.923a4.026 4.026 0 0 1 4.028-4.028c1.16 0 2.207.486 2.943 1.272a7.957 7.957 0 0 0 2.556-.973 4.02 4.02 0 0 1-1.771 2.22 8.073 8.073 0 0 0 2.319-.624 8.645 8.645 0 0 1-2.019 2.083z"
                                        ></path>
                                    </svg>
                                    </div>
                                    <!--INSTAGRAM ICON-->
                                    <div
                                    class="border hover:bg-[#bc2a8d] w-12 h-12 fill-[#bc2a8d] hover:fill-white border-pink-200 rounded-full flex items-center justify-center shadow-xl hover:shadow-pink-500/50 cursor-pointer"
                                    >
                                    <svg
                                        xmlns="http://www.w3.org/2000/svg"
                                        width="24"
                                        height="24"
                                        viewBox="0 0 24 24"
                                    >
                                        <path
                                        d="M11.999 7.377a4.623 4.623 0 1 0 0 9.248 4.623 4.623 0 0 0 0-9.248zm0 7.627a3.004 3.004 0 1 1 0-6.008 3.004 3.004 0 0 1 0 6.008z"
                                        ></path>
                                        <circle cx="16.806" cy="7.207" r="1.078"></circle>
                                        <path
                                        d="M20.533 6.111A4.605 4.605 0 0 0 17.9 3.479a6.606 6.606 0 0 0-2.186-.42c-.963-.042-1.268-.054-3.71-.054s-2.755 0-3.71.054a6.554 6.554 0 0 0-2.184.42 4.6 4.6 0 0 0-2.633 2.632 6.585 6.585 0 0 0-.419 2.186c-.043.962-.056 1.267-.056 3.71 0 2.442 0 2.753.056 3.71.015.748.156 1.486.419 2.187a4.61 4.61 0 0 0 2.634 2.632 6.584 6.584 0 0 0 2.185.45c.963.042 1.268.055 3.71.055s2.755 0 3.71-.055a6.615 6.615 0 0 0 2.186-.419 4.613 4.613 0 0 0 2.633-2.633c.263-.7.404-1.438.419-2.186.043-.962.056-1.267.056-3.71s0-2.753-.056-3.71a6.581 6.581 0 0 0-.421-2.217zm-1.218 9.532a5.043 5.043 0 0 1-.311 1.688 2.987 2.987 0 0 1-1.712 1.711 4.985 4.985 0 0 1-1.67.311c-.95.044-1.218.055-3.654.055-2.438 0-2.687 0-3.655-.055a4.96 4.96 0 0 1-1.669-.311 2.985 2.985 0 0 1-1.719-1.711 5.08 5.08 0 0 1-.311-1.669c-.043-.95-.053-1.218-.053-3.654 0-2.437 0-2.686.053-3.655a5.038 5.038 0 0 1 .311-1.687c.305-.789.93-1.41 1.719-1.712a5.01 5.01 0 0 1 1.669-.311c.951-.043 1.218-.055 3.655-.055s2.687 0 3.654.055a4.96 4.96 0 0 1 1.67.311 2.991 2.991 0 0 1 1.712 1.712 5.08 5.08 0 0 1 .311 1.669c.043.951.054 1.218.054 3.655 0 2.436 0 2.698-.043 3.654h-.011z"
                                        ></path>
                                    </svg>
                                    </div>

                                    <!--WHATSAPP ICON-->
                                    <div
                                    class="border hover:bg-[#25D366] w-12 h-12 fill-[#25D366] hover:fill-white border-green-200 rounded-full flex items-center justify-center shadow-xl hover:shadow-green-500/50 cursor-pointer"
                                    >
                                    <svg
                                        xmlns="http://www.w3.org/2000/svg"
                                        width="24"
                                        height="24"
                                        viewBox="0 0 24 24"
                                    >
                                        <path
                                        fill-rule="evenodd"
                                        clip-rule="evenodd"
                                        d="M18.403 5.633A8.919 8.919 0 0 0 12.053 3c-4.948 0-8.976 4.027-8.978 8.977 0 1.582.413 3.126 1.198 4.488L3 21.116l4.759-1.249a8.981 8.981 0 0 0 4.29 1.093h.004c4.947 0 8.975-4.027 8.977-8.977a8.926 8.926 0 0 0-2.627-6.35m-6.35 13.812h-.003a7.446 7.446 0 0 1-3.798-1.041l-.272-.162-2.824.741.753-2.753-.177-.282a7.448 7.448 0 0 1-1.141-3.971c.002-4.114 3.349-7.461 7.465-7.461a7.413 7.413 0 0 1 5.275 2.188 7.42 7.42 0 0 1 2.183 5.279c-.002 4.114-3.349 7.462-7.461 7.462m4.093-5.589c-.225-.113-1.327-.655-1.533-.73-.205-.075-.354-.112-.504.112s-.58.729-.711.879-.262.168-.486.056-.947-.349-1.804-1.113c-.667-.595-1.117-1.329-1.248-1.554s-.014-.346.099-.458c.101-.1.224-.262.336-.393.112-.131.149-.224.224-.374s.038-.281-.019-.393c-.056-.113-.505-1.217-.692-1.666-.181-.435-.366-.377-.504-.383a9.65 9.65 0 0 0-.429-.008.826.826 0 0 0-.599.28c-.206.225-.785.767-.785 1.871s.804 2.171.916 2.321c.112.15 1.582 2.415 3.832 3.387.536.231.954.369 1.279.473.537.171 1.026.146 1.413.089.431-.064 1.327-.542 1.514-1.066.187-.524.187-.973.131-1.067-.056-.094-.207-.151-.43-.263"
                                        ></path>
                                    </svg>
                                    </div>

                                    <!--TELEGRAM ICON-->
                                    <div
                                    class="border hover:bg-[#229ED9] w-12 h-12 fill-[#229ED9] hover:fill-white border-sky-200 rounded-full flex items-center justify-center shadow-xl hover:shadow-sky-500/50 cursor-pointer"
                                    >
                                    <svg
                                        xmlns="http://www.w3.org/2000/svg"
                                        width="24"
                                        height="24"
                                        viewBox="0 0 24 24"
                                    >
                                        <path
                                        d="m20.665 3.717-17.73 6.837c-1.21.486-1.203 1.161-.222 1.462l4.552 1.42 10.532-6.645c.498-.303.953-.14.579.192l-8.533 7.701h-.002l.002.001-.314 4.692c.46 0 .663-.211.921-.46l2.211-2.15 4.599 3.397c.848.467 1.457.227 1.668-.785l3.019-14.228c.309-1.239-.473-1.8-1.282-1.434z"
                                        ></path>
                                    </svg>
                                    </div>
                                </div>

                                <p class="text-sm">Or copy link</p>
                                <!--BOX LINK-->
                                <div class="border-2 border-gray-200 flex rounded justify-between items-center mt-4 py-2">
                                    <svg
                                    xmlns="http://www.w3.org/2000/svg"
                                    width="24"
                                    height="24"
                                    viewBox="0 0 24 24"
                                    class="fill-gray-500 ml-2"
                                    >
                                    <path
                                        d="M8.465 11.293c1.133-1.133 3.109-1.133 4.242 0l.707.707 1.414-1.414-.707-.707c-.943-.944-2.199-1.465-3.535-1.465s-2.592.521-3.535 1.465L4.929 12a5.008 5.008 0 0 0 0 7.071 4.983 4.983 0 0 0 3.535 1.462A4.982 4.982 0 0 0 12 19.071l.707-.707-1.414-1.414-.707.707a3.007 3.007 0 0 1-4.243 0 3.005 3.005 0 0 1 0-4.243l2.122-2.121z"
                                    ></path>
                                    <path
                                        d="m12 4.929-.707.707 1.414 1.414.707-.707a3.007 3.007 0 0 1 4.243 0 3.005 3.005 0 0 1 0 4.243l-2.122 2.121c-1.133 1.133-3.109 1.133-4.242 0L10.586 12l-1.414 1.414.707.707c.943.944 2.199 1.465 3.535 1.465s2.592-.521 3.535-1.465L19.071 12a5.008 5.008 0 0 0 0-7.071 5.006 5.006 0 0 0-7.071 0z"
                                    ></path>
                                    </svg>

                                    <input class="w-full outline-none bg-transparent border-0" type="text" placeholder="link" value="https://epuero.com/news/1sXCSAQ1">

                                    <button class="bg-indigo-500 text-white rounded text-sm py-2 px-5 mr-2 hover:bg-indigo-600">
                                        Copy
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </template>
    </view-layout>
</template>

<script>
import { Head, Link } from '@inertiajs/inertia-vue3'
import ViewLayout from '@/Layouts/ViewLayout.vue'
import { Icon } from '@iconify/vue'
import Pagination from '@/Components/Pagination.vue'

export default {
    data() {
        return {
        }
    },
    components: {
        Head,
        Link,
        ViewLayout,
        Icon,
        Pagination,
    },
}

</script>

<style>
@import "../../../../css/customize.css";
</style>
