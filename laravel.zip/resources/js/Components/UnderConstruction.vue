<template>
    <div class="w-full inline-block min-h-screen flex items-center">
        <div>
            <h1 class="text-7xl font-bold">(^_^);</h1>
            <h6 class="text-2xl font-semibold mt-4 text-indigo-600">Oops. Kami mohon maaf</h6>
            <span class="text-gray-600">Halaman ini masih dalam proses pengerjaan.</span>
        </div>
    </div>
</template>

<script>
export default {
    name: "UnderConstruction"
}
</script>
